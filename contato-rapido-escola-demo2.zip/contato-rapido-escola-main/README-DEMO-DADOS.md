# Versão de demonstração

Versão preparada para competição: 6 turmas fictícias (3 turmas de dois anos), com nomes e contatos fictícios.
